# Reeda PDF — Android project

A native Android PDF reader/annotation starter for stylus-equipped tablets.

## Included
- Open PDFs using Android's document picker (no broad storage permission).
- Render PDF pages with Android `PdfRenderer`.
- Stylus-only ink input (finger input is left to scrolling).
- Blue pen, red pen, yellow highlighter, eraser, undo, page navigation.
- Export a flattened annotated PDF using Android `PdfDocument`.

## Build an APK
This workspace did not have the Android SDK or Gradle installed, so an APK could not be compiled or device-tested here. To build:
1. Install Android Studio on a computer.
2. Open this `ReedaPdf` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to the Moto tablet and install it. You may need to allow installation from that file manager.

## Moto Pen notes
The drawing view checks Android's `TOOL_TYPE_STYLUS` and `TOOL_TYPE_ERASER` events. This works with Android styluses that report themselves as a stylus. Actual pen pressure, tilt, button shortcuts, and hardware palm rejection depend on the tablet's digitizer/firmware; this project does not claim vendor-specific Moto SDK integration. The tablet should be tested with the physical Moto Pen.

## Current limitations
- Handwriting is stored in memory while the document is open; export before closing to preserve annotations.
- The eraser removes the stroke nearest the touch point.
- No lasso, pressure-sensitive brush, bookmarks, text search, or autosave database yet.
