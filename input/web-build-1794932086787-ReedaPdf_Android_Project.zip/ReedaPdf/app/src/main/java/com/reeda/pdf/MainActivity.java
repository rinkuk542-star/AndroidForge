package com.reeda.pdf;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.database.*;
import android.provider.OpenableColumns;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK_PDF=10, CREATE_PDF=11;
    PdfRenderer renderer; ParcelFileDescriptor pfd; Uri sourceUri;
    int pageIndex=0; PageView pageView; TextView status;
    final ArrayList<ArrayList<Stroke>> pages = new ArrayList<>();
    int inkColor=Color.rgb(25,65,180); float inkWidth=4.2f; boolean eraser=false;
    String docName="";

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(23,37,84)); showHome(); }
    void showHome(){
        LinearLayout root=column(); root.setPadding(28,36,28,28);
        TextView title=text("Reeda PDF",30,true); root.addView(title);
        root.addView(text("Read, write and revise with your Moto Pen.",16,false));
        Button open=button("Open PDF"); open.setOnClickListener(v->pickPdf()); root.addView(open);
        root.addView(text("Pen-first handwriting • Highlighter • Eraser • Undo • Export annotated PDF",14,false));
        setContentView(root);
    }
    LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setBackgroundColor(Color.rgb(246,248,252)); return l; }
    TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(25,35,55)); if(bold)t.setTypeface(null,1); t.setPadding(8,12,8,12); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); return b; }
    void pickPdf(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/pdf"); startActivityForResult(i,PICK_PDF); }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(c!=RESULT_OK||d==null)return;
        try { if(r==PICK_PDF){ sourceUri=d.getData(); getContentResolver().takePersistableUriPermission(sourceUri,Intent.FLAG_GRANT_READ_URI_PERMISSION); openPdf(); }
        else if(r==CREATE_PDF) exportPdf(d.getData()); } catch(Exception e){ toast("Could not open or export: "+e.getMessage()); }
    }
    void openPdf() throws Exception {
        if(renderer!=null)renderer.close(); if(pfd!=null)pfd.close();
        pfd=getContentResolver().openFileDescriptor(sourceUri,"r"); renderer=new PdfRenderer(pfd); pageIndex=0;
        pages.clear(); for(int i=0;i<renderer.getPageCount();i++) pages.add(new ArrayList<>());
        docName=queryName(sourceUri); showReader();
    }
    String queryName(Uri u){ try(Cursor c=getContentResolver().query(u,null,null,null,null)){ if(c!=null&&c.moveToFirst()){int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(x>=0)return c.getString(x);} }catch(Exception e){} return "document.pdf"; }
    void showReader(){
        LinearLayout root=column();
        LinearLayout bar=new LinearLayout(this); bar.setOrientation(0); bar.setGravity(Gravity.CENTER_VERTICAL);
        Button back=button("Files"); back.setOnClickListener(v->{ if(renderer!=null)try{renderer.close();pfd.close();}catch(Exception e){} showHome();}); bar.addView(back);
        Button prev=button("‹"); prev.setOnClickListener(v->goPage(-1)); bar.addView(prev);
        status=text("",14,true); bar.addView(status,new LinearLayout.LayoutParams(0,-2,1));
        Button next=button("›"); next.setOnClickListener(v->goPage(1)); bar.addView(next);
        Button save=button("Export"); save.setOnClickListener(v->createExport()); bar.addView(save);
        root.addView(bar);
        LinearLayout tools=new LinearLayout(this); tools.setOrientation(0);
        Button pen=button("Pen"); pen.setOnClickListener(v->{eraser=false;inkWidth=4.2f;inkColor=Color.rgb(25,65,180);});
        Button high=button("Highlight"); high.setOnClickListener(v->{eraser=false;inkWidth=18f;inkColor=Color.argb(90,255,220,0);});
        Button red=button("Red"); red.setOnClickListener(v->{eraser=false;inkWidth=4.2f;inkColor=Color.RED;});
        Button erase=button("Eraser"); erase.setOnClickListener(v->{eraser=true;});
        Button undo=button("Undo"); undo.setOnClickListener(v->{ArrayList<Stroke> a=pages.get(pageIndex);if(!a.isEmpty()){a.remove(a.size()-1);pageView.invalidate();}});
        tools.addView(pen);tools.addView(high);tools.addView(red);tools.addView(erase);tools.addView(undo); root.addView(tools);
        ScrollView scroll=new ScrollView(this); pageView=new PageView(); scroll.addView(pageView); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); refreshStatus();
    }
    void goPage(int n){ if(renderer==null)return; pageIndex=Math.max(0,Math.min(renderer.getPageCount()-1,pageIndex+n)); pageView.invalidate();refreshStatus(); }
    void refreshStatus(){ if(status!=null)status.setText((pageIndex+1)+" / "+renderer.getPageCount()+"   "+docName); }
    void createExport(){ if(renderer==null)return; Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,"Reeda_"+docName);startActivityForResult(i,CREATE_PDF); }
    void exportPdf(Uri dest) throws Exception {
        PdfDocument out=new PdfDocument();
        for(int i=0;i<renderer.getPageCount();i++){
            PdfRenderer.Page src=renderer.openPage(i); int w=src.getWidth(),h=src.getHeight();
            PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(w,h,i+1).create(); PdfDocument.Page p=out.startPage(info);
            Canvas c=p.getCanvas(); src.render(c,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); src.close();
            drawStrokes(c,pages.get(i),w,h);
            out.finishPage(p);
        }
        try(OutputStream os=getContentResolver().openOutputStream(dest)){out.writeTo(os);} out.close(); toast("Annotated PDF exported");
    }
    void drawStrokes(Canvas c,ArrayList<Stroke> strokes,float w,float h){
        Paint p=new Paint(3); for(Stroke s:strokes){p.setColor(s.color);p.setStrokeWidth(s.width);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
            Path path=new Path(); if(s.points.size()>0){PointF a=s.points.get(0);path.moveTo(a.x*w,a.y*h);for(int j=1;j<s.points.size();j++){PointF b=s.points.get(j);path.lineTo(b.x*w,b.y*h);}}
            c.drawPath(path,p);
        }
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    class Stroke { int color; float width; ArrayList<PointF> points=new ArrayList<>(); Stroke(int c,float w){color=c;width=w;} }
    class PageView extends View {
        Bitmap bitmap; Paint paint=new Paint(3); float scale=1; float offX,offY;
        PageView(){super(MainActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);setFocusable(true);}
        void load(){ if(renderer==null)return; PdfRenderer.Page p=renderer.openPage(pageIndex); int maxW=Math.max(700,getResources().getDisplayMetrics().widthPixels*2); float ratio=(float)p.getHeight()/p.getWidth(); int w=Math.min(maxW,1800),h=(int)(w*ratio); if(bitmap!=null)bitmap.recycle();bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);bitmap.eraseColor(Color.WHITE);p.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);p.close(); }
        @Override protected void onMeasure(int ws,int hs){int w=MeasureSpec.getSize(ws); if(renderer!=null){if(bitmap==null)load();float r=(float)bitmap.getHeight()/bitmap.getWidth();int h=(int)(w*r);setMeasuredDimension(w,h);}else setMeasuredDimension(w,500);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);if(renderer==null)return;if(bitmap==null)load();float w=getWidth(),h=getHeight();c.drawBitmap(bitmap,null,new RectF(0,0,w,h),paint);
            ArrayList<Stroke> a=pages.get(pageIndex);drawStrokes(c,a,w,h);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(renderer==null)return false;
            int tool=e.getToolType(e.getActionIndex());
            // Pen/stylus input is always ink. Finger gestures are left for scrolling/zooming.
            if(tool!=MotionEvent.TOOL_TYPE_STYLUS && tool!=MotionEvent.TOOL_TYPE_ERASER)return false;
            float x=Math.max(0,Math.min(1,e.getX()/getWidth())), y=Math.max(0,Math.min(1,e.getY()/getHeight()));
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                if(eraser||tool==MotionEvent.TOOL_TYPE_ERASER){eraseNear(x,y);invalidate();return true;}
                Stroke s=new Stroke(inkColor,inkWidth);s.points.add(new PointF(x,y));pages.get(pageIndex).add(s);invalidate();return true;
            } else if(e.getAction()==MotionEvent.ACTION_MOVE){
                Stroke s=pages.get(pageIndex).get(pages.get(pageIndex).size()-1);
                for(int i=0;i<e.getHistorySize();i++)s.points.add(new PointF(clamp(e.getHistoricalX(i)/getWidth()),clamp(e.getHistoricalY(i)/getHeight())));
                s.points.add(new PointF(x,y));invalidate();return true;
            } else if(e.getAction()==MotionEvent.ACTION_UP){return true;}
            return true;
        }
        float clamp(float f){return Math.max(0,Math.min(1,f));}
        void eraseNear(float x,float y){ArrayList<Stroke>a=pages.get(pageIndex);for(int i=a.size()-1;i>=0;i--){Stroke s=a.get(i);for(PointF p:s.points)if(Math.hypot((p.x-x)*getWidth(),(p.y-y)*getHeight())<32){a.remove(i);return;}}}
    }
    @Override protected void onDestroy(){super.onDestroy();try{if(renderer!=null)renderer.close();if(pfd!=null)pfd.close();}catch(Exception e){}}
}
